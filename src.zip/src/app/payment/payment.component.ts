import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-payment',
  standalone: false,
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent {
  bdisplaypaymentdone = false
  bdisplayupiform = false
  bdisplayatmcardform = false
 
  upiform! : FormGroup
  atmcardform! : FormGroup
 
  upi(){
    this.bdisplayupiform = true
    this.bdisplayatmcardform = false
  }
 
  card(){
    this.bdisplayatmcardform = true
    this.bdisplayupiform = false
  }
 
  paymentsuccessful(){
    this.bdisplaypaymentdone = true
  }
}
