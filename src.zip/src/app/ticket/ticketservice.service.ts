import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TicketData } from './TicketData';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TicketserviceService {

  constructor(private http:HttpClient) { }

  strURL = "http://localhost:8080/"

  getAllEvents():Observable<any>{

    let strgetUrl = this.strURL + "getallevents"
    return this.http.get(strgetUrl)
  }
  
  
  addBookTicket(nEventId:number,nEmailId:string):Observable<any>{
    //let strgetUrl = this.strURL+"bookTicket?eventid="+nEventId+"&userid="+nEmailId;
    //let ticketObjJSON = JSON.stringify(nEventId,nEmailId)
    let strBookTicketURL = this.strURL + "bookTicket";
    const ticket = {'eventid': nEventId, 'emailid':nEmailId}
    // alert ("URL : "+strBookTicketURL)
    // alert ("Event id : "+nEventId + "  User Id : "+nEmailId)

    //let ticketObj = new TicketData(nEventId, nEmailId, new Date(), "");
    return this.http.post(strBookTicketURL, ticket,{'responseType':'text'});
  }

  cancelTicket(nEventId:number,nEmailId:string):Observable<any>{
    let strCancelTicketURL = this.strURL + "cancelTicket"
    const ticket = {'eventid':nEventId,'emailid':nEmailId}
    alert ("URL : "+strCancelTicketURL)
    alert ("Event id : "+nEventId + "  User Id : "+nEmailId)
    let ticketObj= new TicketData(nEventId,nEmailId,new Date(),"")
    let body=JSON.stringify(ticketObj);
    return this.http.put(strCancelTicketURL,body, {'responseType':'text'})
  }


  getmaxfeedbackid():Observable<any>{
    let getUrl = this.strURL + "getmaxfeedbackid"
    return this.http.get(getUrl)
  }
 
  getfeedbackbyeid(eid: number): Observable<any>{
    let getUrl = this.strURL + "viewfeedback/" + eid
    return this.http.get(getUrl);
  }
 
  addFeedbackRecord(feedbackObj: any): Observable<any> {
    let insertStrUrl = this.strURL + "insertfeedback";
    let feedbackObjJSON = JSON.stringify(feedbackObj)
 
    let headers = {'content-type': 'application/json'}
 
    return this.http.post(insertStrUrl, feedbackObjJSON, {'headers': headers, 'responseType':'text'})
  }
 
  EditFeedbackRecord(feedbackObj: any): Observable<any> {
    let editStrUrl = this.strURL + "updatefeedback";
    let feedbackObjJSON = JSON.stringify(feedbackObj)
 
    let headers = {'content-type': 'application/json'}
 
    return this.http.put(editStrUrl, feedbackObjJSON, {'headers':headers, 'responseType': 'text'})
  }
 
  deleteRecord(feedbackId: number): Observable<any> {
    let deleterStrUrl = this.strURL + "deletefeedback/" + feedbackId;
    return this.http.delete(deleterStrUrl, {'responseType':'text'})
  }
}
