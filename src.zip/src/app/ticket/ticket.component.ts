import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TicketserviceService } from './ticketservice.service';
import { EventData } from './EventData';
import { feedback } from './feedback';
import { FormsModule } from '@angular/forms';
import { Modal } from 'bootstrap';

@Component({
  selector: 'app-ticket',
  standalone: false,
  templateUrl: './ticket.component.html',
  styleUrl: './ticket.component.css'
})
export class TicketComponent {

  strEmail = localStorage.getItem('Email ID')
  bDisplay=true;
  bDisplayEventDetails=false;
  registrationForm!:FormGroup
  bPaymentStatus=false;
  bDisplayTicketRegister = false
  constructor(private ticketService:TicketserviceService,private router:Router,private fb:FormBuilder){
    this.registrationForm=this.fb.group({
        name:['',Validators.required],
        email:['',[Validators.required,Validators.email]],
        tickets:[this.count]
    });
    this.feedbackForm = this.fb.group({
      feedbackId: [''],
      eventId: [''],
      emailId: [''],
      rating: [''],
      comments: ['']
    })
 
  }
 
 
  eventList:any
 
  ngOnInit(){
    if(this.bDisplay){
      this.getAllEvents()
     
    }
  }
 
 getAllEvents(){
  this.ticketService.getAllEvents().subscribe({
    next:(data)=> {this.eventList=data},
    error:(err)=>console.log("Event error"+err),
    complete:()=>console.log("Displayed all events")
  });
 }
 
 gotoShowTickets(){
   this.router.navigate(['/showtickets'])
 }
 
 currentEvent!:{eventid:number;name:string;location:string;date:Date;category:string}
 
 
 eventDetails(eventObj:EventData){
  this.getfeedbackbyeid(eventObj.eventid)
  this.bDisplay=false;
  this.currentEvent = {
    eventid:eventObj.eventid,
    name: eventObj.name,
    location : eventObj.location,
    category: eventObj.category,
    date:eventObj.date
  }
  this.bDisplayEventDetails=true;
 }
 name:string='';
 email:string='';
 count:number=1
 ticketprice=1000;
 totalprice=1000;
 increment(){
  this.count++;
  this.totalprice=(this.count)*1000;
 }
 
 decrement(){
  if(this.count>0){
    --this.count
    this.totalprice=(this.count)*1000;
  }
 }
 
// Modal
 
@ViewChild('registerModal') registerModal!: ElementRef;
 
hideModal() {
  const modalElement = this.registerModal.nativeElement;
  const modalInstance = Modal.getInstance(modalElement) || new Modal(modalElement);
  modalInstance.hide();
 
 
  // Manually remove the backdrop
  const backdrop = document.querySelector('.modal-backdrop');
    if (backdrop) {
      backdrop.remove();
    }
 
  // Also remove 'modal-open' class from body
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('padding-right');
 
}
 
 
 
 addBookTicket(){
 
  let nEventId=this.currentEvent.eventid;
  let strEmailId=(this.strEmail != null)?this.strEmail.toString():'';
  this.ticketService.addBookTicket(nEventId,strEmailId).subscribe({
    next : (data)=>{
      this.router.navigate(['/payment']) },
    error : (err)=>console.log("TicketError"+err),
    complete : () => console.log("Ticket booked successfully")
  });
  this.hideModal();
  this.bDisplayEventDetails=false;
  this.bPaymentStatus=true
  }
 
 
cancelTicket(){
    let nEventId=this.currentEvent.eventid
    let strEmailId=(this.strEmail != null)?this.strEmail.toString():'';
    this.ticketService.cancelTicket(nEventId,strEmailId).subscribe({
    next : (data)=>{alert(data)},
    error : (err)=>console.log("TicketError"+err),
    complete : () => console.log("Ticket cancelled successfully")
 
});
}
 
bookticket(){
  this.bDisplayTicketRegister = true
}


 
 
  eventId = 0;
  feedbackList: any;
  feedbackForm!: FormGroup;
  selectedFeedbackId: number | null = null;
 
  bdisplaypaymentdone = false
  bDisplayEditRecord = false
  bDisplayAddRecord = false
  strDisplayHeaderTagForAddOrEdit = ""
 
  selectedRating: number | null = null;
 
  setRating(rate: number) {
    this.selectedRating = rate;
    this.feedbackForm.get('rating')?.setValue(rate);
    console.log("selected rating", rate)
  }
 
  getfeedbackbyeid(eventId: number) {
    this.eventId = eventId;
    this.ticketService.getfeedbackbyeid(eventId).subscribe({
      next: (data) => { this.feedbackList = data; console.log(data) },
      error: (err) => alert(err),
      complete: () => console.log("Get is completed")
    })
    this.bDisplayEditRecord = false
    this.bDisplayAddRecord = false
  }
 
  addfeedback() {
    this.bDisplayAddRecord = true
    this.strDisplayHeaderTagForAddOrEdit = "Add Record";
 
    // simulating sequential IDs
    let newEmailId = (this.strEmail != null)?this.strEmail.toString():'';
    let newEventId = this.currentEvent.eventid;
 
    this.ticketService.getmaxfeedbackid().subscribe({
      next: (maxFId: number) => {
        const newFeedbackId = maxFId + 1;
 
        this.feedbackForm.patchValue({
          feedbackId: newFeedbackId,
          eventId: newEventId,
          emailId: newEmailId,
          rating: '',
          comments: '',
        });
      },
      error: (err) => {
        console.error("Error fetching max feedback ID:", err);
        alert("Unbale to fetch feedback ID. Please try again.");
      }
    });
  }
 
  editRecord(feedbackObj: feedback) {
    this.bDisplayEditRecord = !this.bDisplayEditRecord
    this.selectedFeedbackId = feedbackObj.feedbackId;
    this.strDisplayHeaderTagForAddOrEdit = "Edit Record";
 
    this.feedbackForm.patchValue({
      feedbackId: feedbackObj.feedbackId,
      eventId: feedbackObj.eventId,
      emailId: feedbackObj.emailId,
      rating: feedbackObj.rating,
      comments: feedbackObj.comments
    })
 
    this.selectedRating = feedbackObj.rating;
  }
 
  deleteRecord(feedbackId: number) {
    this.ticketService.deleteRecord(feedbackId).subscribe({
      next: (data) => { this.getfeedbackbyeid(this.eventId); },
      error: (err) => console.log('Error is : ' + JSON.stringify(err)),
      complete: () => console.log("Delete operation is completed")
    })
  }
 
 
  AddOrEditARecord() {
    let nFeedbackId = this.feedbackForm.get(['feedbackId'])?.value;
    let nEventId = this.currentEvent.eventid
   
    let nEmailId = (this.strEmail != null)?this.strEmail.toString():'';
    let nRating = this.feedbackForm.get(['rating'])?.value;
    let strComments = this.feedbackForm.get(['comments'])?.value;
 
    let feedbackObj = new feedback(nFeedbackId, nEventId, nEmailId, nRating, strComments)
    console.log(feedbackObj)
 
    if (this.strDisplayHeaderTagForAddOrEdit == "Add Record")
      this.ticketService.addFeedbackRecord(feedbackObj).subscribe({
        next: (data) => { this.getfeedbackbyeid(nEventId); this.feedbackForm.reset(); this.selectedRating = null; },
        error: (err) => console.log('Error is: ' + err),
        complete: () => console.log('Add operataion is completed')
      })
 
    else if (this.strDisplayHeaderTagForAddOrEdit == "Edit Record")
      this.ticketService.EditFeedbackRecord(feedbackObj).subscribe({
        next: (data) => { this.getfeedbackbyeid(nEventId); this.feedbackForm.reset(); this.selectedRating = null; },
        error: (err) => console.log('Error is: ' + err),
        complete: () => console.log('Edit operataion is completed')
      })
 
 
    this.bDisplayAddRecord = false
    this.bDisplayEditRecord = false
    this.selectedFeedbackId = null;
  }
 
  getFromsessionStorage(){
    let strEventId = sessionStorage.getItem('EventId')
    let strUserId = sessionStorage.getItem('UserId')
 
  }
}
