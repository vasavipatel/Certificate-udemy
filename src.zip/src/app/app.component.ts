import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'EventManagement';

  

  isLoggedIn:boolean=false
  appName="BooknGo"

  constructor(public router:Router){}

  ngOnInit(){
      let flag = sessionStorage.getItem('loggedin')
      if(flag)
      {
        this.isLoggedIn=true
      }
  }


  logOut(){
    console.log("logout")
    sessionStorage.removeItem('loggedin');
    sessionStorage.removeItem('Email ID');
    // this.router.navigate(["/login"])
    window.location.href='/login'
  }



}
