import { Component } from '@angular/core';
import { UserService } from './user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { user } from './user';

// @Component defines a component in angular , its a decorator
@Component({
  selector: 'app-user',
  standalone: false,
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {

  isAdminPage = false;
  bLoginUser=true;
  AddForm!:FormGroup;
  LoginForm!:FormGroup;
  loginErrorMessage: string = '';
  RegisterErrorMessage:string='';

  constructor(private userService:UserService,private fb:FormBuilder, private router:Router){

    this.AddForm=this.fb.group({
      emailid:['',[Validators.required, Validators.email]],
      username:['',Validators.required],
      password:['',[Validators.required,Validators.minLength(5)]],
      phoneno:['',[Validators.required, Validators.pattern(/^\d{10}$/)]]
    })
      this.LoginForm=this.fb.group({
      emailid:['',[Validators.required, Validators.email]],
      password:['',[Validators.required,Validators.minLength(5)]]
    })
    this.router.events.subscribe(() => {
      this.isAdminPage = this.router.url.includes('/admin');
    });
  
  }

  RegisterUser(){
    this.bLoginUser=false;
    this.AddForm.patchValue({
      emailid:'',
      username:'',
      password:'',
      phoneno:''
    })
  }


  LoginUser(){
    this.bLoginUser=true;
    this.LoginForm.patchValue({
      emailid:'',
      password:''
    })
  }

  AddingUserRecord(){
    let emailid = this.AddForm.get('emailid')?.value;
    let username = this.AddForm.get('username')?.value;
    let password = this.AddForm.get('password')?.value;
    let phoneno = this.AddForm.get('phoneno')?.value;
    let UserObj = new user(emailid, username, password, phoneno);
    this.userService.AddNewUser(UserObj).subscribe({
      next: (data) => {
        if(data==="New user created successfully."){
          alert(data)
          this.RegisterErrorMessage='';
        }
        else{
          this.RegisterErrorMessage=data;
        }
      },
      error: (err) =>{ console.log("error is " + err);
        this.RegisterErrorMessage = 'An error occurred. Please try again.';
      },
      complete: () => console.log("adding record completed")
    });
  }

  LoginUserRecord() {
    let emailid = this.LoginForm.get('emailid')?.value;
    let password = this.LoginForm.get('password')?.value;
    let UserObj = new user(emailid, "", password, 0);
    localStorage.setItem("Email ID", emailid);
    this.userService.LoginUser(UserObj).subscribe({
      next: (data) => {
        if (data === 'valid user') {
          alert("User Logged in Successfully")
          this.loginErrorMessage = '';
          if (emailid === "admin@gmail.com" && password === "admin") {
            sessionStorage.setItem('loggedin', 'true');
            window.location.href = '/admin';
          } else {
            sessionStorage.setItem('loggedin', 'true');
            window.location.href = '/homepage';
          }
        }
        else{
          this.loginErrorMessage='Enter Valid Credentials';
        }
      },
      error: (err) => {
        console.log("error occurred " + err);
        this.loginErrorMessage = 'An error occurred. Please try again.';
      },
      complete: () => {
        console.log("completed log in")
      }
    });
  }
  
}
