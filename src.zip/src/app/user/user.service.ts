import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { user } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http:HttpClient) {}
  strURL="http://localhost:8080/User/"
  AddNewUser(UserObj:user):Observable<any>{
    let InsertStrURL=this.strURL+"CreateUser";
    let UserObjJson=JSON.stringify(UserObj);
    let headers={'content-type':'application/json'}
    return this.http.post(InsertStrURL,UserObjJson,{'headers':headers,'responseType':'text'})
  }

  LoginUser(UserObj:user):Observable<any>{
    let LoginUrl = this.strURL+"LoginUser";
    let body = JSON.stringify(UserObj);
    let headers={'content-type':'application/json'}
    return this.http.post(LoginUrl, body, { headers, responseType: 'text' });
  }
}
