// POJO class of user 
export class user{
    username!:string;
    emailid!:string;
    password!:string;
    phoneno!:number;
    // Parameterised constructor that accepts various fields required for user
    constructor(emailid:string,username:string,password:string,phoneno:number){
        this.username=username;
        this.emailid=emailid;
        this.password=password;
        this.phoneno=phoneno;
    }
}