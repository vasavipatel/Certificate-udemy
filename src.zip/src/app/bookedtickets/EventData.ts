export class EventData{
    eventid!:number;
    organizerid!:number;
    name!:string;
    location!:string;
    category!:string;
    date!:Date;

    constructor(eventid:number,organizerid:number,name:string,location:string,category:string,date:Date){
        this.eventid = eventid;
		this.organizerid = organizerid;
		this.name = name;
		this.location = location;
		this.category = category;
		this.date = date;

        }
}