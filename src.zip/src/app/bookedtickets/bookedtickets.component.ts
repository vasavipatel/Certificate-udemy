import { Component, ElementRef, ViewChild } from '@angular/core';
import { BookedticketsService } from './bookedtickets.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { feedback } from './feedback';
import { Modal } from 'bootstrap';

@Component({
  selector: 'app-bookedtickets',
  standalone: false,
  templateUrl: './bookedtickets.component.html',
  styleUrl: './bookedtickets.component.css'
})
export class BookedticketsComponent {

  constructor(private bookedtickets:BookedticketsService, private fb:FormBuilder){
    this.feedbackForm = this.fb.group({
      feedbackId: [''],
      eventId: [''],
      emailId: [''],
      rating: [''],
      comments: [''],
      submittedTimeStamp: Date.now()
    })
  }
 
  reventId=0
 
  eventList:any
  strEmail = localStorage.getItem('Email ID')
 
 
  ngOnInit() {
    this.getAllBookedEvents();
  }
 
 
  getAllBookedEvents(){
    let strEmailId=(this.strEmail != null)?this.strEmail.toString():'';
    this.bookedtickets.getAllBookedEvents(strEmailId).subscribe({
      next:(data)=> {this.eventList=data;
 
       
        console.log ("Ticekts.."+JSON.stringify(data))},
      error:(err)=>console.log("Event error"+err),
      complete:()=>console.log("Displayed all events")
    });
   }
 
   cancelTicket(eventId:number){
    let strEmailId=(this.strEmail != null)?this.strEmail.toString():'';
    this.bookedtickets.cancelTicket(eventId,strEmailId).subscribe({
      next : (data)=>{alert(data);
        this.getAllBookedEvents();
      },
      error : (err)=>console.log("TicketError"+err),
      complete : () => console.log("Ticket cancelled successfully")
    });
  }
 
  //  currentEvent!:{eventid:number;name:string;location:string;date:Date;category:string}
 
    feedbackList: any;
    feedbackForm!: FormGroup;
    selectedFeedbackId: number | null = null;
    bdisplaypaymentdone = false
    bDisplayEditRecord = false
    bDisplayAddRecord = false
    strDisplayHeaderTagForAddOrEdit = ""
   
    selectedRating: number | null = null;
 
    setRating(rate: number) {
      this.selectedRating = rate;
      this.feedbackForm.get('rating')?.setValue(rate);
      console.log("selected rating", rate)
    }
 
   
 
    @ViewChild('feedbackModal') feedbackModal!: ElementRef;
 
    closeFeedbackModal() {
      const modalElement = this.feedbackModal.nativeElement;
      const modalInstance = Modal.getInstance(modalElement) || new Modal(modalElement);
      modalInstance.hide();
     
      // Manually remove lingering backdrop
      const backdrop = document.querySelector('.modal-backdrop');
      if (backdrop) {
        backdrop.remove();
      }
     
      // Remove modal-open class and reset body styles
      document.body.classList.remove('modal-open');
      document.body.style.removeProperty('padding-right');  
    }
   
    addfeedback(eventid:number) {
      this.bDisplayAddRecord = true
      this.strDisplayHeaderTagForAddOrEdit = "Add Record";
     
      let newEmailId = (this.strEmail != null)?this.strEmail.toString():'';
      console.log("The email id ",newEmailId);
      this.reventId=eventid;
      this.bookedtickets.getmaxfeedbackid().subscribe({
        next: (maxFId: number) => {
          const newFeedbackId = maxFId + 1;
   
          this.feedbackForm.patchValue({
            feedbackId: newFeedbackId,
            eventId: this.reventId,
            emailId: newEmailId,
            rating: '',
            comments: '',
            submittedTimeStamp: ''
          });
        },
        error: (err) => {
          console.error("Error fetching max feedback ID:", err);
          alert("Unbale to fetch feedback ID. Please try again.");
        }
      });
    }
   
    editfeedback(feedbackObj: feedback) {
 
      this.bDisplayEditRecord = !this.bDisplayEditRecord
      this.selectedFeedbackId = feedbackObj.feedbackId;
      this.strDisplayHeaderTagForAddOrEdit = "Edit Record";
   
      this.feedbackForm.patchValue({
        feedbackId: feedbackObj.feedbackId,
        eventId: feedbackObj.eventId,
        emailId: feedbackObj.emailId,
        rating: feedbackObj.rating,
        comments: feedbackObj.comments
      })
   
      this.selectedRating = feedbackObj.rating;
    }
   
    // deleteRecord(feedbackId: number) {
    //   this.bookedtickets.deleteRecord(feedbackId).subscribe({
    //     next: (data) => { this.getfeedbackbyeid(this.eventId); },
    //     error: (err) => console.log('Error is : ' + JSON.stringify(err)),
    //     complete: () => console.log("Delete operation is completed")
    //   })
    // }
   
   
    AddOrEditARecord() {
      let nFeedbackId = this.feedbackForm.get(['feedbackId'])?.value;
      let nEventId = this.reventId;
      let nEmailId = (this.strEmail != null)?this.strEmail.toString():'';
      let nRating = this.feedbackForm.get(['rating'])?.value;
      let strComments = this.feedbackForm.get(['comments'])?.value;
      let submittedTimeStamp = new Date();
      let feedbackObj = new feedback(nFeedbackId, nEventId, nEmailId, nRating, strComments,submittedTimeStamp)
      console.log(feedbackObj)
   
 
      if (this.feedbackForm.valid) {
      // Your logic to save feedback
        this.closeFeedbackModal(); // Close modal after submission
      }else {
        this.feedbackForm.markAllAsTouched(); // Show validation errors
      }
 
      if (this.strDisplayHeaderTagForAddOrEdit == "Add Record")
        this.bookedtickets.addFeedbackRecord(feedbackObj).subscribe({
          next: (data) => { this.feedbackForm.reset(); this.selectedRating = null; },
          error: (err) => console.log('Error is: ' + err),
          complete: () => console.log('Add operataion is completed')
        })
   
      else if (this.strDisplayHeaderTagForAddOrEdit == "Edit Record")
        this.bookedtickets.EditFeedbackRecord(feedbackObj).subscribe({
          next: (data) => { this.feedbackForm.reset(); this.selectedRating = null; },
          error: (err) => console.log('Error is: ' + err),
          complete: () => console.log('Edit operataion is completed')
        })
   
      this.bDisplayAddRecord = false
      this.bDisplayEditRecord = false
      this.selectedFeedbackId = null;
    }
}
