export class feedback{
    feedbackId! : number
    eventId! : number
    emailId! : string
    rating! : number
    comments! : string
    submittedTimeStamp!: Date
    
    constructor(feedbackId:number, eventId: number, emailId: string, rating: number, comments: string, submittedTimeStamp: Date){
        this.feedbackId = feedbackId;
        this.eventId = eventId;
        this.emailId = emailId;
        this.rating =rating;
        this.comments = comments
        this.submittedTimeStamp = submittedTimeStamp;
    }
}