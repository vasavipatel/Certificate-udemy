import { TestBed } from '@angular/core/testing';

import { BookedticketsService } from './bookedtickets.service';

describe('BookedticketsService', () => {
  let service: BookedticketsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BookedticketsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
