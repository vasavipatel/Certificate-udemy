export class TicketData{
    eventid! : number;
    userid! : string;
    ticketid! : number;
    bookingdate! : Date;
    status! : string;

    constructor (eventid:number, userid:string, bookingdate:Date, status:string ){
        this.eventid = eventid;
        this.userid = userid;
        this.bookingdate = bookingdate;
        this.status = status;
    }


    
}