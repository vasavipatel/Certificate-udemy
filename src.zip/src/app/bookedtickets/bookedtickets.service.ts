import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TicketData } from './TicketData';
import { feedback } from './feedback';

@Injectable({
  providedIn: 'root'
})
export class BookedticketsService {
  
  constructor(private http:HttpClient) { }

  strURL = "http://localhost:8080/"

  getAllBookedEvents(nEmailId:string):Observable<any>{

    let strBookTicketURL = this.strURL + "viewTheBookedTicketsForSpecificUser?emailId="+nEmailId;
      //  const ticket = {'emailid':nEmailId}
       // alert ("URL : "+strBookTicketURL)       
    
        return this.http.get<any[]>(strBookTicketURL); 
  }

  cancelTicket(nEventId:number,nEmailId:string):Observable<any>{
      let strCancelTicketURL = this.strURL + "cancelTicket"
      const ticket = {'eventid':nEventId,'emailid':nEmailId}
      alert ("URL : "+strCancelTicketURL)
      alert ("Event id : "+nEventId + "  User Id : "+nEmailId)
  
      let ticketObj= new TicketData(nEventId,nEmailId,new Date(),"")
      return this.http.put(strCancelTicketURL,ticket, {'responseType':'text'})
    }

  getmaxfeedbackid():Observable<any>{
    let getUrl = this.strURL + "getmaxfeedbackid"
    return this.http.get(getUrl)
  }
 
  getfeedbackbyeid(eid: number): Observable<any>{
    let getUrl = this.strURL + "viewfeedback/" + eid
    return this.http.get(getUrl);
  }
 
  addFeedbackRecord(feedbackObj: any): Observable<any> {
    let insertStrUrl = this.strURL + "insertfeedback";
    let feedbackObjJSON = JSON.stringify(feedbackObj)
 
    let headers = {'content-type': 'application/json'}
 
    return this.http.post(insertStrUrl, feedbackObjJSON, {'headers': headers, 'responseType':'text'})
  }
 
  EditFeedbackRecord(feedbackObj: any): Observable<any> {
    let editStrUrl = this.strURL + "updatefeedback";
    let feedbackObjJSON = JSON.stringify(feedbackObj)
 
    let headers = {'content-type': 'application/json'}
 
    return this.http.put(editStrUrl, feedbackObjJSON, {'headers':headers, 'responseType': 'text'})
  }
 
  deleteRecord(feedbackId: number): Observable<any> {
    let deleterStrUrl = this.strURL + "deletefeedback/" + feedbackId;
    return this.http.delete(deleterStrUrl, {'responseType':'text'})
  }


}