import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TicketComponent } from './ticket/ticket.component';
import { UserComponent } from './user/user.component';
import { EventComponent } from './event/event.component';
import { PaymentComponent } from './payment/payment.component';
import { AdminComponent } from './admin/admin.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { UseradminComponent } from './useradmin/useradmin.component';
import { BookedticketsComponent } from './bookedtickets/bookedtickets.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {path:'login',component:UserComponent},
  {path:'eventadmin', component:EventComponent},
  {path:'homepage', component:TicketComponent},
  {path:'useradmin',component:UseradminComponent},
  {path:'payment', component: PaymentComponent},
  {path:'admin',component:AdminComponent},
  {path:'feedbackadmin',component:FeedbackComponent},
  {path:'showtickets',component:BookedticketsComponent},
  {path:'',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
