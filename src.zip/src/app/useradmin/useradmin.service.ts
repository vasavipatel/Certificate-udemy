import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { user } from './user';

@Injectable({
  providedIn: 'root'
})
export class UseradminService {
 
  constructor(private http:HttpClient) {
  }
  strURL="http://localhost:8080/User/";
  getAllUsers():Observable<any>{
    let strGetAllUsers=this.strURL+"AllUsers";
    return this.http.get(strGetAllUsers);
  }
  AddNewUser(UserObj:user):Observable<any>{
    let insertStrUrl=this.strURL+"CreateUser";
    let UserObJson=JSON.stringify(UserObj);
    let headers={'content-type':'application/json'} //response type : text
    return this.http.post(insertStrUrl,UserObJson,{'headers':headers,'responseType':'text'});
  }
 
  EditUser(UserObj:user):Observable<any>{
    let EditStrUrl=this.strURL+"UpdateUser";
    let UserObjJson=JSON.stringify(UserObj);
    let headers={'content-type':'application/json'}//response type : text
    return this.http.put(EditStrUrl,UserObjJson,{'headers':headers,'responseType':'text'});
  }
 
  DeleteUser(emailid:string):Observable<any>{
    console.log(emailid)
    let deleteStrUrl=this.strURL+"DeleteUser/"+emailid;
    return this.http.delete(deleteStrUrl,{'responseType':'text'})
  }
}
