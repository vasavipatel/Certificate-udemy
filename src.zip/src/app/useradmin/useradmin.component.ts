import { Component } from '@angular/core';
import { UseradminService } from './useradmin.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { user } from './user';

@Component({
  selector: 'app-useradmin',
  standalone: false,
  templateUrl: './useradmin.component.html',
  styleUrl: './useradmin.component.css'
})
export class UseradminComponent {
  AddForm!:FormGroup;
  title = 'UserCrud';
  bDisplayUsers=false;
  UserLst!:any;
  ErrorMessage:string='';
  bDisplayAddOrEditARecord=false;
  strDisplayHeaderTagForAddorEdit="";

  constructor(private RestService:UseradminService,private fb:FormBuilder){
    this.AddForm=this.fb.group({
      username:['',Validators.required],
      emailid:['',[Validators.required,Validators.email]],
      password:['',[Validators.required,Validators.minLength(5)]],
      phoneno:['',[Validators.required, Validators.pattern(/^\d{10}$/)]]
    })
  }

  getAllUsers(){
    this.bDisplayUsers=true;
    this.bDisplayAddOrEditARecord=false;
    this.RestService.getAllUsers().subscribe({
      next:(data)=>{this.UserLst=data},
      error:(err)=>console.log('User error : '+err),
      complete:()=>console.log("get completed")
    });
  }

  addUserRecord(){
    this.bDisplayAddOrEditARecord=true;
    this.strDisplayHeaderTagForAddorEdit="Add Record";
    this.bDisplayUsers=false
    this.AddForm.patchValue(
      {
        username:'',
        emailid:'',
        password:'',
        phoneno:''
      }
    )
  }
 
  EditUserRecord(UserObj: user) {
    console.log("EditUserRecord called");
    this.bDisplayAddOrEditARecord = true;
    this.strDisplayHeaderTagForAddorEdit = "Edit Record";
    this.bDisplayUsers = false;
    this.AddForm.patchValue({
      username: UserObj.username,
      emailid: UserObj.emailid,
      password: UserObj.password,
      phoneno: UserObj.phoneno
    });
    console.log("Form values after patch:", this.AddForm.value);
  }
 
  AddingOrEditingARecord(){
    let username=this.AddForm.get(['username'])?.value;
    let emailid=this.AddForm.get(['emailid'])?.value;
    let password=this.AddForm.get(['password'])?.value;
    let phoneno=this.AddForm.get(['phoneno'])?.value;
    let UserObj=new user(emailid,username,password,phoneno);
 
    if(this.strDisplayHeaderTagForAddorEdit=="Add Record"){
      this.RestService.AddNewUser(UserObj).subscribe({
        next:(data)=>{alert(data); this.getAllUsers();},
        error:(err)=>{
          console.log("error is : "+err)
          this.ErrorMessage=err;
        },
        complete:()=>console.log("adding record completed")
      })
    }
    else if(this.strDisplayHeaderTagForAddorEdit=="Edit Record"){
      this.RestService.EditUser(UserObj).subscribe({
        next:(data)=>{alert(data); this.getAllUsers();},
        error:(err)=>
          {console.log("error is : "+err)
          this.ErrorMessage=err;
        },
        complete:()=>console.log("editing record completed")
      })
    }
  }

  DeleteUserRecord(emailid:string){
    this.RestService.DeleteUser(emailid).subscribe({
      next:(data)=>{alert(data);this.getAllUsers();},
      error:(err)=>console.log("cant delete record : "+JSON.stringify(err)),
      complete:()=>console.log("record deleted ")
    })
  }
}