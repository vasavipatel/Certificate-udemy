// POJO Class for user object creation
export class user{
    username!:string;
    emailid!:string;
    password!:string;
    phoneno!:number;
    constructor(emailid:string,username:string,password:string,phoneno:number){
        this.username=username;
        this.emailid=emailid;
        this.password=password;
        this.phoneno=phoneno;
    }
}