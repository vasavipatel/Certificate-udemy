import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
 
@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
 
  constructor(private http:HttpClient) { }
 
 
  strURL = "http://localhost:8080/"
 
  getallfeedbacks():Observable<any>{
 
    let strgetUrl = this.strURL + "getallfeedbacks"
    let xyz = this.http.get(strgetUrl)
    return this.http.get(strgetUrl)
  }
 
  getmaxfeedbackid():Observable<any>{
    let getUrl = this.strURL + "getmaxfeedbackid"
    return this.http.get(getUrl)
  }
 
  getfeedbackbyeid(eid: number): Observable<any>{
    let getUrl = this.strURL + "viewfeedback/" + eid
    return this.http.get(getUrl);
  }
 
  addFeedbackRecord(feedbackObj: any): Observable<any> {
    let insertStrUrl = this.strURL + "insertfeedback";
    let feedbackObjJSON = JSON.stringify(feedbackObj)
 
    let headers = {'content-type': 'application/json'}
 
    return this.http.post(insertStrUrl, feedbackObjJSON, {'headers': headers, 'responseType':'text'})
  }
 
  EditFeedbackRecord(feedbackObj: any): Observable<any> {
    let editStrUrl = this.strURL + "updatefeedback";
    let feedbackObjJSON = JSON.stringify(feedbackObj)
 
    let headers = {'content-type': 'application/json'}
 
    return this.http.put(editStrUrl, feedbackObjJSON, {'headers':headers, 'responseType': 'text'})
  }
 
  deleteRecord(feedbackId: number): Observable<any> {
    let deleteStrUrl = this.strURL + "deletefeedback/" + feedbackId;
    return this.http.delete(deleteStrUrl, {'responseType':'text'})
  }
}
 