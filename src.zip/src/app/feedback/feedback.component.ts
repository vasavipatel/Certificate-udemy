import { Component } from '@angular/core';
import { FeedbackService } from './feedback.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { feedback } from './feedback'
 
 
@Component({
  selector: 'app-feedback',
  standalone: false,
  templateUrl: './feedback.component.html',
  styleUrl: './feedback.component.css'
})
export class FeedbackComponent {
 
  newUserId = 1;
  newEventId = 101;
  eventId = 0;
  feedbackList: any;
  feedbackForm!: FormGroup;
  selectedFeedbackId: number | null = null;
 
 
  bDisplayAddOrEditARecord = false
  bdisplaypaymentdone = false
  bDisplayEditRecord = false
  bDisplayAddRecord = false
  strDisplayHeaderTagForAddOrEdit = ""
  bDisplayFeedbacks = false
  // selectedRating: number | null = null;
 
  constructor(private feedbackService:FeedbackService,private router:Router,private fb:FormBuilder){
    this.feedbackForm = this.fb.group({
     
    feedbackId: ['', Validators.required],
    eventId: ['', Validators.required],
    emailId: ['', [Validators.required, Validators.email]],
    rating: ['', [Validators.required, Validators.min(1), Validators.max(10)]],
    comments: ['', [Validators.maxLength(200)]]
 
    })
 
  }
 
 
  // setRating(rate: number) {
  //   this.selectedRating = rate;
  //   this.feedbackForm.get('rating')?.setValue(rate);
  //   console.log("selected rating", rate)
  // }
 
  getallfeedbacks() {
    this.bDisplayFeedbacks = true
    this.feedbackService.getallfeedbacks().subscribe({
      next: (data) => { this.feedbackList = data; console.log(data) },
      error: (err) => {console.log(err)},
      complete: () => console.log("Get is completed")
    })
    this.bDisplayEditRecord = false
    this.bDisplayAddRecord = false
  }
 
  addfeedback() {
    this.bDisplayAddRecord = true
    this.bDisplayFeedbacks = false
    this.strDisplayHeaderTagForAddOrEdit = "Add Record";
 
    // simulating sequential IDs
 
    this.feedbackService.getmaxfeedbackid().subscribe({
      next: (maxFId: number) => {
        const newFeedbackId = maxFId + 1;
        console.log(newFeedbackId);
        this.feedbackForm.patchValue({
          feedbackId: newFeedbackId,
          eventId: '',
          emailId: '',
          rating: '',
          comments: '',
        });
      },
      error: (err) => {
        console.error("Error fetching max feedback ID:", err);
        alert("Unbale to fetch feedback ID. Please try again.");
      }
    });
  }
 
  editRecord(feedbackObj: feedback) {
    this.bDisplayEditRecord = !this.bDisplayEditRecord
    this.selectedFeedbackId = feedbackObj.feedbackId;
    this.strDisplayHeaderTagForAddOrEdit = "Edit Record";
 
    this.feedbackForm.patchValue({
      feedbackId: feedbackObj.feedbackId,
      eventId: feedbackObj.eventId,
      emailId: feedbackObj.emailId,
      rating: feedbackObj.rating,
      comments: feedbackObj.comments
    })
 
    // this.selectedRating = feedbackObj.rating;
  }
 
  deleteRecord(feedbackId: number) {
    this.feedbackService.deleteRecord(feedbackId).subscribe({
      next: (data) => { this.getallfeedbacks();},
      error: (err) => console.log('Error is : ' + JSON.stringify(err)),
      complete: () => console.log("Delete operation is completed")
    })
  }
 
 
  AddOrEditARecord() {
    let nFeedbackId = this.feedbackForm.get(['feedbackId'])?.value;
    let nEventId = this.feedbackForm.get(['eventId'])?.value;
    console.log(nEventId+'Eventid');
    let nEmailId = this.feedbackForm.get(['emailId'])?.value;
    let nRating = this.feedbackForm.get(['rating'])?.value;
    let strComments = this.feedbackForm.get(['comments'])?.value;
    let submittedTimeStamp = new Date();
 
    if(nRating < 0 || nRating >10){
      alert("Rating should be in the range of 1 to 10")
    }else{
      let feedbackObj = new feedback(nFeedbackId, nEventId, nEmailId, nRating, strComments, submittedTimeStamp)
      console.log(feedbackObj)
      if (this.strDisplayHeaderTagForAddOrEdit == "Add Record")
        this.feedbackService.addFeedbackRecord(feedbackObj).subscribe({
          next: (data) => { this.getallfeedbacks(); this.feedbackForm.reset(); },
          error: (err) => console.log('Error is: ' + err),
          complete: () => console.log('Add operataion is completed')
        })
 
      else if (this.strDisplayHeaderTagForAddOrEdit == "Edit Record")
        this.feedbackService.EditFeedbackRecord(feedbackObj).subscribe({
          next: (data) => { this.getallfeedbacks(); this.feedbackForm.reset();},
          error: (err) => console.log('Error is: ' + err),
          complete: () => console.log('Edit operataion is completed')
        })
 
 
      this.bDisplayAddRecord = false
      this.bDisplayEditRecord = false
      this.selectedFeedbackId = null;
    }
  }
  CloseAddOrEditForm(){
    this.bDisplayAddRecord=false;
  }
 
  CloseAllFeedbacks(){
    this.bDisplayFeedbacks=false;
  }
}