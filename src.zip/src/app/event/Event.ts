export class Event
{
    eventid!:number;
    name!:string;
    organizerid!:number;
    category!:string;
    date!:string;
    location!:string
 
    constructor(eventid:number,name:string,organizerid:number,category:string,date:string,location:string)
    {
        this.eventid=eventid;
        this.name=name;
        this.organizerid=organizerid;
        this.category=category;
        this.date=date;
        this.location=location;
    }
}