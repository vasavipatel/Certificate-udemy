import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EventService } from './event.service';
import { Event } from './Event';
@Component({
  selector: 'app-event',
  standalone: false,
  templateUrl: './event.component.html',
  styleUrl: './event.component.css'
})
export class EventComponent {

  addevent()
{
  this.bdisplayrecord=true;
  this.strdisplayheadertagforaddoredit="Add record";
  this.eventform.patchValue(
    {
      eventid:'',
      name:'',
      date:'',
      category:'',
      location:'',
      organizerid:'',
    }
  )
}
eventform!:FormGroup
bdisplayrecord=false;
toggling=false;
 
constructor(private fb: FormBuilder,private eventservice:EventService) {
this.eventform=this.fb.group({
  eventid:[''],
  organizerid:[''],
  name:[''],
  category:[''],
  date:[''],
  location:['']
});
}
 
strdisplayheadertagforaddoredit="";
 
 
eventlst:any
getAllEvents()
{
  console.log("getting")
  this.toggling=true
  this.bdisplayrecord = true;
this.eventservice.getAllEvents().subscribe({
next:(data)=>{this.eventlst=data;},
error:(err)=>console.log('employees error:'+err),
complete:()=>console.log('Get is completed')
});
}
 
eventsubmitrecord()
{
  console.log("EVent submit record called");
 
  console.log(this.eventform.value);
  let nid=this.eventform.get(['eventid'])?.value;
  let nname=this.eventform.get(['name'])?.value;
  let ncategory=this.eventform.get(['category'])?.value;
  let ndate=this.eventform.get(['date'])?.value;
  let nlocation=this.eventform.get(['location'])?.value;
  let norganizerid= this.eventform.get(['organizerid'])?.value;
 
  let empobj=new Event(nid,nname,norganizerid,ncategory,ndate,nlocation);
 
  // alert ("Given record is : "+JSON.stringify(empobj));
  // alert (this.strdisplayheadertagforaddoredit);
 
  if(this.strdisplayheadertagforaddoredit=="Add Event")
  {
  this.eventservice.addevent(empobj).subscribe(
    {
      next:(data)=>{this.getAllEvents()},
      error:(err)=>console.log("Error is" +JSON.stringify(err)),
      complete:()=>console.log("adding done......")
    }
  )
}
 
else if(this.strdisplayheadertagforaddoredit=="Edit Event")
  {
    this.eventservice.editevent(empobj).subscribe({
      next:(data)=>{alert("event details updated successfully ");this.getAllEvents();},
      error:(err)=>console.log('Error is : ' + err),
      complete : () => console.log('Edit operation is complete..')
    })
  }
  }
 
  editRecord(eventObj: Event){
    // alert ("Received data is : "+ JSON.stringify(eventObj));
    this.strdisplayheadertagforaddoredit = "Edit Event";
    this.bdisplayrecord = true;
   this.toggling=false
    // from the ts file, event object, let it go to eventForm..
    this.eventform.patchValue({
      eventid : eventObj. eventid,
      organizerid : eventObj.organizerid,
      name : eventObj.name,
      category : eventObj.category,
      location : eventObj.location,
      date : eventObj.date
    })
  }
 
 
  deleteRecord(eventid : number){
    this.eventservice.deleteevent(eventid).subscribe({
      next : (data) => { this.getAllEvents();},
      error : (err) => console.log('Error is :' + JSON.stringify(err)),
      complete : () => console.log("Delete operation is complete..")
    })
   }
 
   addrecord()
   {
    console.log("The add record is called");
    this.toggling=false;
    this.bdisplayrecord=true;
    this.strdisplayheadertagforaddoredit="Add Event";
    this.eventform.patchValue({
      eventid : '',
      organizerid : '',
      name:'',
      category:'',
      location:'',
      date:'',
      image:''
    })
   }
 
   selectedCategory:string="";
   selectedLocation:string="";
   selectedDate:string="";
   filteredEvents:Event[]=[];
   bAndingOfFilter = false;
   num=0;
   
   filterEvents() {
    this.filteredEvents = this.eventlst.filter((event: Event) => {
      const matchesCategory = this.selectedCategory
        ? event.category.toLowerCase().includes(this.selectedCategory.toLowerCase())
        : true;
 
       
      const matchesLocation = this.selectedLocation
        ? event.location.toLowerCase().includes(this.selectedLocation.toLowerCase())
        : true;
 
        console.log (JSON.stringify(this.filteredEvents))
       
 
      const matchesDate = this.selectedDate
        ? new Date(event.date).toISOString().split('T')[0] === this.selectedDate
        : true;
 
        this.bAndingOfFilter = matchesCategory && matchesLocation && matchesDate;
 
        if (this.selectedLocation != null || this.selectedCategory != null || this.selectedDate != null)
          this.num = 1;
      return this.bAndingOfFilter;
    });
  }
 
 
 

}
