import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Event } from './Event';
@Injectable({
  providedIn: 'root'
})
export class EventService {

  constructor(private http: HttpClient) { }
  strurl="http://localhost:8080"
 
getAllEvents():Observable<any>
{
let strurl=this.strurl+"/getallevents";
return this.http.get(strurl);
  }
 
addevent(eveobj:Event):Observable<any>
{
let inserturl=this.strurl+"/insertevent";
// alert ("URL : "+inserturl);
let empobjJSON=JSON.stringify(eveobj);
let headers = {'Content-Type':'application/json'};
return this.http.post(inserturl,empobjJSON,{'headers':headers,'responseType':'text'});
}
 
editevent(eveobj:Event):Observable<any>
{
  let updateurl=this.strurl+"/updateevent";
  let empobjJSON=JSON.stringify(eveobj);
  let headers = {'Content-Type':'application/json'};
  return this.http.put(updateurl,empobjJSON,{'headers':headers,'responseType':'text'});
}
 
deleteevent(id:number):Observable<any>
{
  let strdeleteurl=this.strurl+"/deleteevent/" +id ;
  return this.http.delete(strdeleteurl,{'responseType':'text'});
}
}
