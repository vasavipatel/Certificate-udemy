package com.example.demo.service;

import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.UserDAO;
import com.example.demo.model.User;
 
@Service
public class UserService {
 
    @Autowired
    private UserDAO userDao;
 
    public List<User> displayAllUsers() {
        return userDao.displayAllUsers();
    }
 
   
 
    public String updateUser(User userObj) {
        return userDao.updateUser(userObj);
    }
 
    public String createUser(User userObj) {
        return userDao.createUser(userObj);
    }
 
    public String deleteUserAccount(String emailid) {
        return userDao.deleteUserAccount(emailid);
    }
 
    public String loginUser(User userObj) {
        return userDao.loginUser(userObj);
    }
 
 
	public User GetUserAccount(String emailid) {
		// TODO Auto-generated method stub
		return userDao.GetUserAccount(emailid);
	}
	
	
}