package com.example.demo.service;

import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.FeedbackDAO;
import com.example.demo.ServiceImpl.FeedbackService;
import com.example.demo.model.Feedback;

 
@Service
public class FeedbackServiceImpl implements FeedbackService{
 
	@Autowired
	FeedbackDAO feedbackdao;
	public List<Feedback> getallfeedbacks(){
		List<Feedback> feedbackList = feedbackdao.getallfeedbacks();
		return feedbackList;
	}
	public List<Feedback> getFeedbacksByEventId(int id){
		List<Feedback> feedbackLst = feedbackdao.getFeedbacksByEId(id);
		return feedbackLst;
	}
	public String insertFeedback(Feedback feedbackObj) {
		feedbackdao.saveFeedback(feedbackObj);
		return "Feedback saved for Event Id:"+ feedbackObj.getEventId();
	}
	public void updateFeedback(Feedback feedbackObj) {
		feedbackdao.saveFeedback(feedbackObj);
	}
 
 
	public void deleteFeedback(int eventid) {
		feedbackdao.deleteFeedback(eventid);
	}
 
	public int getmaxfeedbackid() {
		return feedbackdao.getmaxfeedbackid();
	}
}
