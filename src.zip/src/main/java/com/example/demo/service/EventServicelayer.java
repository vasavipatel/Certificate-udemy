package com.example.demo.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.Eventdao;
import com.example.demo.model.Event;
import com.example.demo.model.TicketData;

@Service
public class EventServicelayer {
	@Autowired
	Eventdao eventdao;
	public String savefb(Event eveobj)
	{
		eventdao.saveevent(eveobj);
		return "Record is submitted successfully";
	}
	
	public List<Event> getallevents()
	{
		
		return eventdao.getallevents();
	}
	public Event getEventbyId(int id)
	{
		return eventdao.getEventbyId(id);
	}
	public List<Event> searchEventByLocation(String location){
		return eventdao.searchEventByLocation(location);
	}
	public List<Event> searchEventByCategory(String category){
		return eventdao.searchEventByCategory(category);
	}
	public List<Event> searchEventByDate(LocalDate date){
		return eventdao.searchEventByDate(date);
	}
	
	public String deleteeve(int id) {
		return eventdao.deleteeve(id);
	}
	public String updateeve(Event eveobj) {
	 return eventdao.updateeve(eveobj);
	}

}
