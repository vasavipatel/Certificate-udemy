package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.TicketDAO;
import com.example.demo.ServiceImpl.TicketServiceInterface;
import com.example.demo.model.Event;
import com.example.demo.model.TicketData;
import java.util.List;

//Indicates that this class is a service component in the Spring context
@Service
public class TicketService implements TicketServiceInterface {

// Automatically injects the TicketDAO bean
	@Autowired
//Declares a DAO object to handle data access operations
	TicketDAO ticketdao;

//Books a ticket using event and user IDs
	public TicketData bookTicket(long eventid, String emailid) {
		System.out.println("Ticket is booked sucessfully");
		return ticketdao.bookTicket(eventid, emailid);
	}

//Cancels a ticket using event and user IDs
	public void cancelTicket(long eventid, String emailid) {
		ticketdao.cancelTicket(eventid, emailid);
//		return "Ticket Cancelled Successfully";
	}

//Retrieves all booked tickets
	public List<TicketData> viewAllBookedTickets() {
		return ticketdao.viewAllBookedTickets();
	}

	 
	public List<Event> viewTickets(String emailid) {
		return ticketdao.viewTickets(emailid);
	}


}
