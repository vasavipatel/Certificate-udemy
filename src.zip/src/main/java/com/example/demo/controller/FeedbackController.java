package com.example.demo.controller;

import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ServiceImpl.FeedbackService;
import com.example.demo.model.Feedback;
import com.example.demo.repository.FeedbackRepository;
//import com.example.demo.service.FeedbackService;
//import com.example.demo.serviceImpl.FeedbackServiceImpl;
 
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class FeedbackController {
	@Autowired
	FeedbackService feedbackService;
	@GetMapping("/getallfeedbacks")
	public List<Feedback> getallfeedbacks(){
		List<Feedback> feedbackList = feedbackService.getallfeedbacks();
		return feedbackList;
	}
	@PostMapping("/insertfeedback")
	public String insertFeedback(@RequestBody Feedback feedbackObj) {
		return feedbackService.insertFeedback(feedbackObj);
	}
	@GetMapping("/viewfeedback/{eventid}")
	public List<Feedback> getFeedbacksByEvent(@PathVariable int eventid){
		List<Feedback> feedbackLst = feedbackService.getFeedbacksByEventId(eventid);
		return feedbackLst;
	}

	@PutMapping("/updatefeedback")
	public String updateFeedback(@RequestBody Feedback feedbackObj) {
		feedbackService.insertFeedback(feedbackObj);
		return "Feedback updated successfully for eventID: "+ feedbackObj.getEventId();
	}
	@DeleteMapping("/deletefeedback/{feedbackid}")
	public String deleteFeedback(@PathVariable int feedbackid) {
		feedbackService.deleteFeedback(feedbackid);
		return "Feedback deleted successfully for FeedbackId:"+feedbackid;
	}
	@GetMapping("/getmaxfeedbackid")
	public int maxfeedbackid() {
		return feedbackService.getmaxfeedbackid();
	}
	
	
}
