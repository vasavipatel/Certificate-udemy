package com.example.demo.controller;

import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.User;
import com.example.demo.service.UserService;
 
@RestController
@RequestMapping("/User")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {
 
    @Autowired
    private UserService service;
 
    @GetMapping("/AllUsers")
    public List<User> displayAllUsers() {
        return service.displayAllUsers();
    }
 
    
 
   @PutMapping("/UpdateUser")
    public String updateUser(@RequestBody User userObj) {
        return service.updateUser(userObj);
    }
   
   	@GetMapping("/GetUser/{emailid}")
   	public User GetUserAccount(@PathVariable String emailid) {
   		return service.GetUserAccount(emailid);
   	}
 
    @PostMapping("/CreateUser")
    public String createUser(@RequestBody User userObj) {
        return service.createUser(userObj);
    }
 
    @DeleteMapping("/DeleteUser/{emailid}")
    public String deleteUserAccount(@PathVariable String emailid) {
        return service.deleteUserAccount(emailid);
    }
 
    @PostMapping("/LoginUser")
    public String loginUser(@RequestBody User userObj) {
        return service.loginUser(userObj);
    }
}