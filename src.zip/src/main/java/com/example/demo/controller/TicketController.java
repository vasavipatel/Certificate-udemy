package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Event;
import com.example.demo.model.TicketData;
import com.example.demo.service.TicketService;

import java.util.List;

//Declares this class as a REST controller to handle web requests
@RestController
@CrossOrigin(origins="http://localhost:4200")
public class TicketController {

// Automatically injects the TicketService bean
	@Autowired

//Declares a service to handle ticket-related operations
	public TicketService ticketService;

//Maps POST requests to /bookTicket 
	@PostMapping("/bookTicket")
	public String bookTicket(@RequestBody  TicketData ticketObj) {
		System.out.println("Ticket object : "+ticketObj);
		ticketService.bookTicket(ticketObj.getEventid(), ticketObj.getEmailid());
		return "Ticket Booked Successfully";
	}

//Maps PUT requests to /cancelTicket
	@PutMapping("/cancelTicket")
	public String cancelTicket(@RequestBody TicketData ticketObj) {
		System.out.println("Ticket object : "+ticketObj);
		ticketService.cancelTicket(ticketObj.getEventid(), ticketObj.getEmailid());
		return "Ticket Cancelled Successfully";
	}

// Maps GET requests to /viewAllBookedTickets
	@GetMapping("/viewAllBookedTickets")
	public List<TicketData> viewAllBookedTickets() {
		List<TicketData> bookedTicketsList = ticketService.viewAllBookedTickets();
		return bookedTicketsList;
	}
	
	@GetMapping("/viewTheBookedTicketsForSpecificUser")
	public List<Event> viewTickets(@RequestParam String emailId) {
		System.out.println("Received email id : "+emailId);
	    return ticketService.viewTickets(emailId);
	}
	
}
