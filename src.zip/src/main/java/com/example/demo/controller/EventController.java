package com.example.demo.controller;
import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model.Event;
import com.example.demo.model.TicketData;
import com.example.demo.service.EventServicelayer;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class EventController {

	@Autowired
	EventServicelayer eveserv;
	@PostMapping("/insertevent")
	public String insertfb(@RequestBody Event obj)
	{
		return eveserv.savefb(obj);
	}
	
	@GetMapping("/getallevents")
	public List<Event> getallevents()
	{
		return eveserv.getallevents();
	}
	@GetMapping("/geteventbyid/{id}")
	public Event geteventbyid(@PathVariable int id)
	{
		return eveserv.getEventbyId(id);
	}
	@GetMapping("/getalleventsbydate")
	public List<Event> geteventsbydate(@RequestParam("date") @DateTimeFormat(iso=DateTimeFormat.ISO.DATE)LocalDate date)
	{
		return eveserv.searchEventByDate(date);
	}
	@GetMapping("/getalleventsbylocation")
	public List<Event> geteventsbylocation(@RequestParam String location)
	{
		return eveserv.searchEventByLocation(location);
	}
	@GetMapping("/getalleventsbycategory")
	public List<Event> geteventsbycategory(@RequestParam String category)
	{
		return eveserv.searchEventByCategory(category);
	}
	@DeleteMapping("/deleteevent/{id}")
	public String deleteevent(@PathVariable int id) {
	    return eveserv.deleteeve(id);
	}
	@PutMapping("/updateevent")
	public String updateevent( @RequestBody Event updatedevent) {
	    return eveserv.updateeve(updatedevent);
	}
	
	
	
}
