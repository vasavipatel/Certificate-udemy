package com.example.demo.repository;
import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Event;
import com.example.demo.model.TicketData;

@Repository
public interface EventRepository extends JpaRepository<Event, Integer>{
	List<Event> findByLocation(String location);
	List<Event> findByCategory(String category);
	List<Event> findByDate(LocalDate date);
}
