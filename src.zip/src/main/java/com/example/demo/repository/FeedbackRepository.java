package com.example.demo.repository;

import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
 
import com.example.demo.model.Feedback;
 
 
@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Integer>{
	// Custom query method to retrieve a list of feedback entries based on the event ID
	// Spring Data JPA automatically implements this method using the method name
 
	public List<Feedback> findByEventId(int id);
 
	@Query(value= "select MAX(feedback_id) from feedback", nativeQuery = true)
	public int getmaxfeedbackid();
}