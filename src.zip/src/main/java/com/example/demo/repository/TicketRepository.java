package com.example.demo.repository; 

import java.util.List; 


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Event;
import com.example.demo.model.TicketData; 

//Declares a repository interface for TicketData with Long as ID type
public interface TicketRepository extends JpaRepository<TicketData,Long> { 

	public TicketData findByEventidAndEmailid(Long eventid, String emailid);
// Custom method to find tickets by user ID and event ID

	List<TicketData> findByEmailid(String emailid);	
	
	@Query(value="SELECT e.* FROM event e JOIN ticket t ON e.eventid = t.eventid where t.emailid = :emailId and t.status='CONFIRMED'", nativeQuery=true)
	List<Event> findEventsByEmaildId(String emailId) ;


	
	
}
