package com.example.demo.DAO;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Event;
import com.example.demo.model.TicketData;
import com.example.demo.model.TicketStatus;
import com.example.demo.repository.TicketRepository;

import jakarta.transaction.Transactional;


//Indicates that this class is a repository component
@Repository
public class TicketDAO {

// Automatically injects the TicketRepository bean
	@Autowired
	TicketRepository ticketrepo;

//Books a new ticket with event and user IDs
	public TicketData bookTicket(long eventId, String emailId) {
		TicketData ticket = new TicketData(eventId, emailId, LocalDateTime.now(), TicketStatus.CONFIRMED);
		return ticketrepo.save(ticket);
	}

	public void cancelTicket(long eventid, String emailid) {
	    TicketData ticket = ticketrepo.findByEventidAndEmailid(eventid, emailid);
	    if(ticket != null) {
	        ticket.setStatus(TicketStatus.CANCELLED);
	        ticketrepo.save(ticket);
	    }
	}

		
	

//Retrieves all booked tickets
	public List<TicketData> viewAllBookedTickets() {
		return ticketrepo.findAll();
	}

	public TicketData findByEventidAndEmailid(long eventid, String emailid) {
		return ticketrepo.findByEventidAndEmailid(eventid,emailid);
	}

	public List<Event> viewTickets(String emailid) {
		List<Event> userBookedTickets = ticketrepo.findEventsByEmaildId(emailid);
		System.out.println("Returning data from view Tickets..."+userBookedTickets);
		return userBookedTickets;
	}
	
}
