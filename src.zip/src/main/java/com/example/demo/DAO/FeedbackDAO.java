package com.example.demo.DAO;

import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
 
import com.example.demo.model.Feedback;
import com.example.demo.repository.FeedbackRepository;
 
@Repository
public class FeedbackDAO {
	@Autowired
	FeedbackRepository feedbackRepo;
	public List<Feedback> getFeedbacksByEId(int id) {
		List<Feedback> feedbackLst = feedbackRepo.findByEventId(id);
		return feedbackLst;
	}
 
	public void saveFeedback(Feedback feedbackObj) {
		feedbackRepo.save(feedbackObj);
	}
	public void deleteFeedback(int eventid) {
		feedbackRepo.deleteById(eventid);
	}
 
	public int getmaxfeedbackid() {
		return feedbackRepo.getmaxfeedbackid();
	}
 
	public List<Feedback> getallfeedbacks() {
		return feedbackRepo.findAll();
	}
}
