package com.example.demo.DAO;
import java.util.List;

import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
 
@Repository
public class UserDAO {
 
    @Autowired
    private UserRepository userRepo;
 
    public List<User> displayAllUsers() {
        return userRepo.findAll();
    }
 
 
    public String updateUser(User userObj) {
        if (userRepo.existsById(userObj.getEmailid())) {
            userRepo.save(userObj);
            return "User details updated successfully.";
        }
        return "User does not exist.";
    }
 
    public String createUser(User userObj) {
    	if(userRepo.existsByEmailid(userObj.getEmailid())) {
    		return "User Already exists with this email";
    	}
        userRepo.save(userObj);
        return "New user created successfully.";
    }
 
    public String deleteUserAccount(String emailid) {
       if(userRepo.existsById(emailid)) {
            userRepo.deleteById(emailid);
            return "User account deleted successfully.";
        }
        return "User account does not exist.";
    }
 
    public String loginUser(User userObj) {
    	String emailid=userObj.getEmailid();
    	String password=userObj.getPassword();
        Optional<User> userOpt = userRepo.findById(emailid);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (user.getPassword().equals(password)) {
                return "valid user";
            } else {
                return "Incorrect password.";
            }
        }
        return "User does not exist.";
    }
 
 
	public User GetUserAccount(String emailid) {
		// TODO Auto-generated method stub
		Optional<User> userOpt = userRepo.findById(emailid);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            return user;
        }
        return null;
	}
}
