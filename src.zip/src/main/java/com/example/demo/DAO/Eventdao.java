package com.example.demo.DAO;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Event;
import com.example.demo.model.TicketData;
import com.example.demo.repository.EventRepository;

@Repository
public class Eventdao {
	@Autowired
	EventRepository eventRepo;
	public String saveevent(Event eveobj)
	{
		eventRepo.save(eveobj);
		return "Record is submitted successfully";
	}
	
	public List<Event> getallevents()
	{
		
		return eventRepo.findAll();
	}
	public Event getEventbyId(int id)
	{
		Optional<Event> event= eventRepo.findById(id);
		return event.orElse(null);
	}
	public List<Event> searchEventByLocation(String location){
		return eventRepo.findByLocation(location);
	}
	public List<Event> searchEventByCategory(String category){
		return eventRepo.findByCategory(category);
	}
	public List<Event> searchEventByDate(LocalDate date){
		return eventRepo.findByDate(date);
	}
	
	public String deleteeve(int id) {
		
		if (eventRepo.existsById(id)) {
				eventRepo.deleteById(id);
		return "deleted successfully!";
		 } 
		else
		{
			 return "ID " + id ;}
		}
	public String updateeve(Event eveobj) {
	 if(eventRepo.existsById(eveobj.getEventid()))
	 {
		 eventRepo.save(eveobj);
		 return " updated successfully!";
	 }
	 return "not found the given id";
	}

}
