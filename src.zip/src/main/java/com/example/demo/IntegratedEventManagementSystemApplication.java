// Defines the base package for the Spring Boot application
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//Enables auto-configuration, component scanning, and configuration for Spring Boot
@SpringBootApplication

//Main class to the Spring Boot application
public class IntegratedEventManagementSystemApplication {

// Main method to start the application
	public static void main(String[] args) {
// Launches the Spring Boot application	
		SpringApplication.run(IntegratedEventManagementSystemApplication.class, args);
	}
}
