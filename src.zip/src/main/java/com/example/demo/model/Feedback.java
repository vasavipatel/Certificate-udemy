package com.example.demo.model;
 
import java.time.LocalDate;
 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
 
@Entity
@Table(name="feedback")

public class Feedback {
	
	@Id
	int feedbackId;
 
	int eventId;
 
	String emailId;
 
	int rating;
	
	String comments;
 
	LocalDate submittedTimeStamp;

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public LocalDate getSubmittedTimeStamp() {
		return submittedTimeStamp;
	}

	public void setSubmittedTimeStamp(LocalDate submittedTimeStamp) {
		this.submittedTimeStamp = submittedTimeStamp;
	}

	Feedback(){}
	
	public Feedback(int feedbackId, int eventId, String emailId, int rating, String comments,
			LocalDate submittedTimeStamp) {
		super();
		this.feedbackId = feedbackId;
		this.eventId = eventId;
		this.emailId = emailId;
		this.rating = rating;
		this.comments = comments;
		this.submittedTimeStamp = submittedTimeStamp;
	}

	
	
}