package com.example.demo.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="event")
public class Event {
	@Id
	@Column(name="eventid")
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int eventid;
	
	@Column(name="organizerid")
	private int organizerid;
	
	@Column(name="name")
	private String name;
	
	@Column(name="location")
	private String location;
	
	@Column(name="category")
	private String category;
	
	@Column(name="date")
	private LocalDate date;
	
	public int getEventid() {
		return eventid;
	}
	public void setEventid(int eventid) {
		this.eventid = eventid;
	}
	public int getOrganizerid() {
		return organizerid;
	}
	public void setOrganizerid(int organizerid) {
		this.organizerid = organizerid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Event(int eventid, int organizerid, String name, String location, String category, LocalDate date) {
		super();
		this.eventid = eventid;
		this.organizerid = organizerid;
		this.name = name;
		this.location = location;
		this.category = category;
		this.date = date;
	}
	public Event() {
	}


}
