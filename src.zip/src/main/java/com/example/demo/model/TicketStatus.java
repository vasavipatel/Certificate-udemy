package com.example.demo.model;

public enum TicketStatus {
	CONFIRMED,
	CANCELLED

}
