package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
 
@Entity
 
public class User {
	@Id
	private String emailid;
	private String username;
	private String password;
	private long phoneno; 
	User(){}
 
	public User(String emailid, String username, String password, long phoneno) {
		super();
		this.emailid = emailid;
		this.username = username;
		this.password = password;
		this.phoneno = phoneno;
	}
 
	public String getEmailid() {
		return emailid;
	}
 
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
 
	public String getUsername() {
		return username;
	}
 
	public void setUsername(String username) {
		this.username = username;
	}
 
	public String getPassword() {
		return password;
	}
 
	public void setPassword(String password) {
		this.password = password;
	}
 
	public long getPhoneno() {
		return phoneno;
	}
 
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
 
	@Override
	public String toString() {
		return "User [emailid=" + emailid + ", username=" + username + ", password=" + password + ", phoneno=" + phoneno
				+ "]";
	}
 
 
	
}