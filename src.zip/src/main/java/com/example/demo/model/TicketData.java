package com.example.demo.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

//Entity annotation is used to represent the database table , it maps the table with the same name in the DB
@Entity

//it specifies the table name if the table name in DB and entity is different
@Table(name="ticket")
public class TicketData {
	
	//its declares the primary key among the fields of the table
	@Id
	
	//auto generates and increments the primary index
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	//the fields of the database where ticketId is the primary key
	private long ticketid;
	private long eventid;
	private String emailid;
	private LocalDateTime bookingdate;
	
	
	//this annotation defines the enum type of field that. The values are defined in other class
	@Enumerated(EnumType.STRING)
	
	//identifies a column with the name that is in the DB
	@Column(name = "status")
	private TicketStatus status;
	
	
	//a no-argument constructor as JPA uses reflection to instantiate the entity objects when loading data from the DB
	public TicketData() {}
	
	//constructor with arguments to initialize the fields
	public TicketData(long eventid, String emailid, LocalDateTime bookingdate, TicketStatus status) {
		super();
		this.eventid = eventid;
		this.emailid = emailid;
		this.bookingdate = bookingdate;
		this.status = status;
	}


	//public setters and getters to access the fields of the data
	public long getTicketid() {
		return ticketid;
	}


	public void setTicketid(long ticketid) {
		this.ticketid = ticketid;
	}


	public long getEventid() {
		return eventid;
	}


	public void setEventid(long eventid) {
		this.eventid = eventid;
	}



	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public LocalDateTime getBookingdate() {
		return bookingdate;
	}


	public void setBookingdate(LocalDateTime bookingdate) {
		this.bookingdate = bookingdate;
	}


	public TicketStatus getStatus() {
		return status;
	}


	public void setStatus(TicketStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "TicketData [ticketid=" + ticketid + ", eventid=" + eventid + ", emailid=" + emailid + ", bookingdate="
				+ bookingdate + ", status=" + status + "]";
	}

	
}
