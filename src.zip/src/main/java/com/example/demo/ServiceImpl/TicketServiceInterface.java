package com.example.demo.ServiceImpl;

import java.util.List;

import com.example.demo.model.TicketData;

public interface TicketServiceInterface {
	public TicketData bookTicket(long eventid, String emailid);
	public void cancelTicket(long eventid, String emailid);
	public List<TicketData> viewAllBookedTickets();
	
}
