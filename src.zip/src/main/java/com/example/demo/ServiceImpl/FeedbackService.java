package com.example.demo.ServiceImpl;

import java.util.List;

import com.example.demo.model.Feedback;
 
public interface FeedbackService {
	public List<Feedback> getFeedbacksByEventId(int id);
	public String insertFeedback(Feedback feedbackObj);
	public void updateFeedback(Feedback feedbackObj); 
	public void deleteFeedback(int eventid);
	public int getmaxfeedbackid();
	public List<Feedback> getallfeedbacks();
}