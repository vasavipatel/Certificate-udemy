package com.example.demo;

import com.example.demo.DAO.UserDAO;
import com.example.demo.model.User;
import com.example.demo.service.UserService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserServiceTest {

    @Mock
    private UserDAO userDao;

    @InjectMocks
    private UserService userService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testDisplayAllUsers() {
        User user1 = new User("Kaveri@gmail.com", "Kaveri Manga", "kaveri", 1392891112L);
        User user2 = new User("Nina@gmail.com", "Nina Singh", "nina123", 1329713221L);
        User user3 = new User("Priya@gmail.com", "Priya", "Priya@12345", 7656568779L);
        User user4 = new User("Sia@gmail.com", "Sia", "siasingh", 2183321232L);

        when(userDao.displayAllUsers()).thenReturn(Arrays.asList(user1, user2, user3, user4));

        List<User> users = userService.displayAllUsers();
        assertEquals(4, users.size());
        assertEquals("Kaveri Manga", users.get(0).getUsername());
    }

    @Test
    public void testCreateUser() {
        User user = new User("Priya@gmail.com", "Priya", "Priya@12345", 7656568779L);
        when(userDao.createUser(user)).thenReturn("User created successfully");

        String result = userService.createUser(user);
        assertEquals("User created successfully", result);
    }

    @Test
    public void testUpdateUser() {
        User user = new User("Sia@gmail.com", "Sia", "newpass", 2183321232L);
        when(userDao.updateUser(user)).thenReturn("User updated successfully");

        String result = userService.updateUser(user);
        assertEquals("User updated successfully", result);
    }

    @Test
    public void testDeleteUserAccount() {
        String email = "Nina@gmail.com";
        when(userDao.deleteUserAccount(email)).thenReturn("User deleted successfully");

        String result = userService.deleteUserAccount(email);
        assertEquals("User deleted successfully", result);
    }

    @Test
    public void testLoginUser() {
        User user = new User("Kaveri@gmail.com", "Kaveri Manga", "kaveri", 1392891112L);
        when(userDao.loginUser(user)).thenReturn("Login successful");

        String result = userService.loginUser(user);
        assertEquals("Login successful", result);
    }

    @Test
    public void testGetUserAccount() {
        String email = "Priya@gmail.com";
        User user = new User(email, "Priya", "Priya@12345", 7656568779L);
        when(userDao.GetUserAccount(email)).thenReturn(user);

        User result = userService.GetUserAccount(email);
        assertNotNull(result);
        assertEquals("Priya", result.getUsername());
    }
}
