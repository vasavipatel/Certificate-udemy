package com.example.demo;

import com.example.demo.DAO.UserDAO;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserDAOTest {

    @Mock
    private UserRepository userRepo;

    @InjectMocks
    private UserDAO userDao;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testDisplayAllUsers() {
        User user1 = new User("Kaveri@gmail.com", "Kaveri Manga", "kaveri", 1392891112L);
        User user2 = new User("Nina@gmail.com", "Nina Singh", "nina123", 1329713221L);

        when(userRepo.findAll()).thenReturn(Arrays.asList(user1, user2));

        List<User> users = userDao.displayAllUsers();
        assertEquals(2, users.size());
        assertEquals("Kaveri Manga", users.get(0).getUsername());
    }

    @Test
    public void testCreateUser_NewUser() {
        User user = new User("Priya@gmail.com", "Priya", "Priya@12345", 7656568779L);
        when(userRepo.existsByEmailid(user.getEmailid())).thenReturn(false);

        String result = userDao.createUser(user);
        verify(userRepo, times(1)).save(user);
        assertEquals("New user created successfully.", result);
    }

    @Test
    public void testCreateUser_ExistingUser() {
        User user = new User("Priya@gmail.com", "Priya", "Priya@12345", 7656568779L);
        when(userRepo.existsByEmailid(user.getEmailid())).thenReturn(true);

        String result = userDao.createUser(user);
        verify(userRepo, never()).save(user);
        assertEquals("User Already exists with this email", result);
    }

    @Test
    public void testUpdateUser_ExistingUser() {
        User user = new User("Sia@gmail.com", "Sia", "newpass", 2183321232L);
        when(userRepo.existsById(user.getEmailid())).thenReturn(true);

        String result = userDao.updateUser(user);
        verify(userRepo, times(1)).save(user);
        assertEquals("User details updated successfully.", result);
    }

    @Test
    public void testUpdateUser_NonExistingUser() {
        User user = new User("unknown@gmail.com", "Unknown", "pass", 1234567890L);
        when(userRepo.existsById(user.getEmailid())).thenReturn(false);

        String result = userDao.updateUser(user);
        verify(userRepo, never()).save(user);
        assertEquals("User does not exist.", result);
    }

    @Test
    public void testDeleteUserAccount_ExistingUser() {
        String email = "Nina@gmail.com";
        when(userRepo.existsById(email)).thenReturn(true);

        String result = userDao.deleteUserAccount(email);
        verify(userRepo, times(1)).deleteById(email);
        assertEquals("User account deleted successfully.", result);
    }

    @Test
    public void testDeleteUserAccount_NonExistingUser() {
        String email = "ghost@gmail.com";
        when(userRepo.existsById(email)).thenReturn(false);

        String result = userDao.deleteUserAccount(email);
        verify(userRepo, never()).deleteById(email);
        assertEquals("User account does not exist.", result);
    }

    @Test
    public void testLoginUser_ValidCredentials() {
        User user = new User("Kaveri@gmail.com", "Kaveri Manga", "kaveri", 1392891112L);
        when(userRepo.findById(user.getEmailid())).thenReturn(Optional.of(user));

        String result = userDao.loginUser(user);
        assertEquals("valid user", result);
    }

    @Test
    public void testLoginUser_IncorrectPassword() {
        User user = new User("Kaveri@gmail.com", "Kaveri Manga", "wrongpass", 1392891112L);
        User storedUser = new User("Kaveri@gmail.com", "Kaveri Manga", "kaveri", 1392891112L);
        when(userRepo.findById(user.getEmailid())).thenReturn(Optional.of(storedUser));

        String result = userDao.loginUser(user);
        assertEquals("Incorrect password.", result);
    }

    @Test
    public void testLoginUser_UserNotFound() {
        User user = new User("ghost@gmail.com", "Ghost", "ghostpass", 1111111111L);
        when(userRepo.findById(user.getEmailid())).thenReturn(Optional.empty());

        String result = userDao.loginUser(user);
        assertEquals("User does not exist.", result);
    }

    @Test
    public void testGetUserAccount_UserExists() {
        String email = "Priya@gmail.com";
        User user = new User(email, "Priya", "Priya@12345", 7656568779L);
        when(userRepo.findById(email)).thenReturn(Optional.of(user));

        User result = userDao.GetUserAccount(email);
        assertNotNull(result);
        assertEquals("Priya", result.getUsername());
    }

    @Test
    public void testGetUserAccount_UserNotFound() {
        String email = "ghost@gmail.com";
        when(userRepo.findById(email)).thenReturn(Optional.empty());

        User result = userDao.GetUserAccount(email);
        assertNull(result);
    }
}
